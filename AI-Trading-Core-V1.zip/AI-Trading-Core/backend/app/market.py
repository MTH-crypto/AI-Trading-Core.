import ccxt
import pandas as pd
from datetime import datetime, timezone
from .config import settings

class MarketDataError(Exception):
    pass

def fetch_ohlcv(symbol: str):
    try:
        exchange_cls = getattr(ccxt, settings.exchange_id)
        exchange = exchange_cls({"enableRateLimit": True, "timeout": 12000})
        rows = exchange.fetch_ohlcv(symbol, timeframe=settings.timeframe, limit=settings.ohlcv_limit)
        if not rows or len(rows) < 55:
            raise MarketDataError(f"Not enough candles for {symbol}")
        df = pd.DataFrame(rows, columns=["timestamp","open","high","low","close","volume"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms", utc=True)
        return df
    except Exception as e:
        raise MarketDataError(f"Market data unavailable for {symbol}: {e}") from e

def latest_market():
    result = {}
    for symbol in settings.symbol_list:
        df = fetch_ohlcv(symbol)
        close = df["close"]
        df["ema20"] = close.ewm(span=20, adjust=False).mean()
        df["ema50"] = close.ewm(span=50, adjust=False).mean()
        delta = close.diff()
        gain = delta.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
        loss = (-delta.clip(upper=0)).ewm(alpha=1/14, adjust=False).mean()
        rs = gain / loss.replace(0, 1e-12)
        df["rsi"] = 100 - (100 / (1 + rs))
        last = df.iloc[-1]
        result[symbol] = {
            "symbol": symbol, "price": float(last.close),
            "ema20": float(last.ema20), "ema50": float(last.ema50),
            "rsi": float(last.rsi), "volume": float(last.volume),
            "candle_time": last.timestamp.isoformat(),
            "candles": [
                {"time": int(r.timestamp.timestamp()), "close": float(r.close)}
                for r in df.tail(80).itertuples()
            ]
        }
    return result

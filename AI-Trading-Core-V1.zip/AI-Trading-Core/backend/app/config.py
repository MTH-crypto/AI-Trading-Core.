from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "AI Trading Core"
    exchange_id: str = "binance"
    symbols: str = "BTC/EUR,ETH/EUR"
    timeframe: str = "15m"
    ohlcv_limit: int = 120
    initial_cash_eur: float = 100.0
    fee_rate: float = 0.001
    slippage_rate: float = 0.0005
    risk_per_trade: float = 0.005
    max_daily_loss_rate: float = 0.02
    max_drawdown_rate: float = 0.05
    poll_seconds: int = 60
    auto_tick: bool = False
    database_path: str = "data/trading.db"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def symbol_list(self):
        return [s.strip() for s in self.symbols.split(",") if s.strip()]

settings = Settings()

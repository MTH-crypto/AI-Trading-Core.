from app.engine import evaluate

def test_buy_signal():
    assert evaluate({"ema20": 110, "ema50": 100, "rsi": 55})[0] == "BUY"

def test_sell_signal():
    assert evaluate({"ema20": 90, "ema50": 100, "rsi": 50})[0] == "SELL"

def test_hold_signal():
    assert evaluate({"ema20": 100, "ema50": 100, "rsi": 45})[0] == "HOLD"

from datetime import datetime, timezone
import json
from .config import settings
from .db import connect
from .market import latest_market

def now():
    return datetime.now(timezone.utc).isoformat()

def evaluate(m):
    # Conservative deterministic baseline. Neutral is a valid and common outcome.
    if m["ema20"] > m["ema50"] and 48 <= m["rsi"] <= 68:
        return "BUY", "EMA20 above EMA50; RSI confirms positive momentum without being overbought."
    if m["ema20"] < m["ema50"] or m["rsi"] >= 74:
        return "SELL", "Trend weakened or RSI is overbought; reduce/close an existing position."
    return "HOLD", "No sufficiently clear setup; preserve capital."

def snapshot():
    market = latest_market()
    with connect() as c:
        p = dict(c.execute("SELECT * FROM portfolio WHERE id=1").fetchone())
        positions = {r["symbol"]: dict(r) for r in c.execute("SELECT * FROM positions")}
        trades = [dict(r) for r in c.execute("SELECT * FROM trades ORDER BY id DESC LIMIT 30")]
        decisions = [dict(r) for r in c.execute("SELECT * FROM decisions ORDER BY id DESC LIMIT 30")]
    equity = p["cash"]
    for symbol, pos in positions.items():
        if symbol in market:
            equity += pos["quantity"] * market[symbol]["price"]
    return {
        "portfolio": {
            "cash": round(p["cash"], 2), "equity": round(equity, 2),
            "initial_cash": p["initial_cash"],
            "pnl": round(equity-p["initial_cash"], 2),
            "pnl_pct": round((equity/p["initial_cash"]-1)*100, 3),
            "drawdown_pct": round((equity/p["peak_equity"]-1)*100, 3) if p["peak_equity"] else 0,
            "halted": bool(p["halted"])
        },
        "market": market, "positions": list(positions.values()),
        "trades": trades, "decisions": decisions
    }

def run_cycle():
    market = latest_market()
    ts = now()
    day = datetime.now(timezone.utc).date().isoformat()
    results = []
    with connect() as c:
        p = c.execute("SELECT * FROM portfolio WHERE id=1").fetchone()
        positions = {r["symbol"]: dict(r) for r in c.execute("SELECT * FROM positions")}
        prices = {s: m["price"] for s,m in market.items()}
        equity = p["cash"] + sum(pos["quantity"] * prices.get(s, 0) for s,pos in positions.items())
        peak = max(p["peak_equity"], equity)
        day_start = p["day_start_equity"] if p["day_key"] == day else equity
        halted = bool(p["halted"])
        if equity <= day_start - p["initial_cash"] * settings.max_daily_loss_rate:
            halted = True
        if equity <= peak * (1-settings.max_drawdown_rate):
            halted = True
        c.execute("UPDATE portfolio SET peak_equity=?, day_start_equity=?, day_key=?, halted=? WHERE id=1",
                  (peak, day_start, day, int(halted)))

        for symbol, m in market.items():
            signal, reason = evaluate(m)
            pos = positions.get(symbol)
            agent_status = {
                "SCANNER": "market data received",
                "ANALYST": f"EMA20/50 and RSI={m['rsi']:.1f} evaluated",
                "SAFETY": "data present; no leverage; spot-only rules",
                "RISK": "daily loss and drawdown guard checked",
                "EXECUTOR": "paper execution only",
                "PORTFOLIO": "portfolio exposure checked"
            }
            if halted:
                signal, reason = "HALT", "Risk circuit breaker active; new transactions blocked."
            elif signal == "BUY" and not pos:
                # Reserve at least half of cash; only use cash available above reserve.
                reserve = max(0.0, p["initial_cash"] * 0.50)
                spend = min(max(0.0, p["cash"] - reserve), equity * 0.25)
                risk_budget = equity * settings.risk_per_trade
                # Notional cap is 25% equity; risk budget is logged as a conservative sizing reference.
                if spend >= 8.0:
                    fill = m["price"] * (1 + settings.slippage_rate)
                    qty = spend / (fill * (1 + settings.fee_rate))
                    fee = qty * fill * settings.fee_rate
                    cost = qty * fill + fee
                    c.execute("UPDATE portfolio SET cash=cash-? WHERE id=1", (cost,))
                    c.execute("INSERT OR REPLACE INTO positions(symbol,quantity,avg_entry) VALUES(?,?,?)",
                              (symbol, qty, fill))
                    c.execute("INSERT INTO trades(timestamp,symbol,side,quantity,price,fee,pnl,reason) VALUES(?,?,?,?,?,?,?,?)",
                              (ts,symbol,"BUY",qty,fill,fee,0.0,reason+f" Risk budget reference €{risk_budget:.2f}."))
                    results.append(f"BUY {symbol} €{cost:.2f}")
                else:
                    signal, reason = "HOLD", "Insufficient cash above reserve for minimum simulated order."
            elif signal == "SELL" and pos:
                fill = m["price"] * (1 - settings.slippage_rate)
                gross = pos["quantity"] * fill
                fee = gross * settings.fee_rate
                proceeds = gross - fee
                pnl = proceeds - pos["quantity"] * pos["avg_entry"]
                c.execute("UPDATE portfolio SET cash=cash+? WHERE id=1", (proceeds,))
                c.execute("DELETE FROM positions WHERE symbol=?", (symbol,))
                c.execute("INSERT INTO trades(timestamp,symbol,side,quantity,price,fee,pnl,reason) VALUES(?,?,?,?,?,?,?,?)",
                          (ts,symbol,"SELL",pos["quantity"],fill,fee,pnl,reason))
                results.append(f"SELL {symbol} P&L €{pnl:.2f}")
            elif signal == "SELL" and not pos:
                signal, reason = "HOLD", "Sell condition detected, but no open position exists."
            c.execute("INSERT INTO decisions(timestamp,symbol,signal,reason,agents) VALUES(?,?,?,?,?)",
                      (ts,symbol,signal,reason,json.dumps(agent_status)))
    return {"timestamp": ts, "actions": results, "market": market}

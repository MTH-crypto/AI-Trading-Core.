# AI Trading Core — V1 Paper Trading

A local-first BTC/EUR + ETH/EUR paper-trading prototype. It uses public market data only; no exchange account, API key, wallet, or real-money order execution is required.

## What works in V1
- FastAPI backend with public OHLCV data through CCXT (Binance by default).
- EMA 20/50 + RSI strategy with a conservative no-trade default.
- Paper portfolio initialized at €100.
- Simulated buys/sells with configurable fee and slippage assumptions.
- Maximum position sizing and daily loss guardrails.
- SQLite persistence for portfolio, trades, and decision log.
- React dashboard with portfolio, BTC/ETH prices, agent status, and trade history.
- Manual refresh / one analysis cycle and optional 60-second background cycle.

## Important limitations
This is a prototype, not a profitable strategy or investment recommendation. Signals are educational and may be noisy. Backtests and paper results do not establish future profitability. No real orders are sent. The “agents” in V1 are deterministic modules, not autonomous LLM agents. This is intentional: risk controls and execution should be deterministic and testable before adding language models.

## Requirements
- Python 3.11+
- Node.js 20+
- Internet access for public exchange market data

## Run backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
API docs: http://127.0.0.1:8000/docs

If market data is unavailable, the API reports the error; it does not invent prices.

## Run frontend
In another terminal:
```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```
Open http://localhost:5173

## Configuration
See `backend/.env.example`. The default exchange is Binance Spot public data, quote currency EUR, initial paper cash €100. No API credentials are used or supported in this V1.

## Safety model
- Spot-only simulation; no leverage, no short selling.
- Max risk budget per entry: 0.5% of current equity.
- Max daily realized loss: 2% of initial capital.
- Max drawdown circuit breaker: 5% from peak equity.
- One open position per asset.
- Estimated fee: 0.10% per side; slippage: 0.05% per side.
- If price data is stale or missing, no trade is allowed.
- This software must not be connected to real-money execution without a separate security review, extensive testing, and explicit redesign.

## Reset paper account
Stop the backend, delete `backend/data/trading.db`, and restart. This resets the demo portfolio to €100.

## Next milestones
1. Add historical backtesting and walk-forward validation.
2. Add WebSocket market streaming and robust stale-data monitoring.
3. Add explainable multi-agent consensus around the deterministic strategy.
4. Add PostgreSQL/Redis and deployment hardening.
5. Only much later, assess whether any real-money integration is appropriate.

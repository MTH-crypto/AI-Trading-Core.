import React, {useEffect, useState} from 'react';
import {Activity, ArrowUpRight, ArrowDownRight, Bot, RefreshCw, ShieldCheck, Wallet, Zap, Clock3, CircleDot} from 'lucide-react';
import {AreaChart, Area, ResponsiveContainer, Tooltip} from 'recharts';

const API = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000';
const money = n => new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR'}).format(Number(n||0));
function App(){
 const [state,setState]=useState(null), [error,setError]=useState(''), [busy,setBusy]=useState(false), [last,setLast]=useState(null);
 async function load(){try{setError('');const r=await fetch(API+'/api/state');if(!r.ok)throw new Error((await r.json()).detail||'API indisponible');setState(await r.json());}catch(e){setError(e.message)}}
 async function cycle(){setBusy(true);try{const r=await fetch(API+'/api/cycle',{method:'POST'});const j=await r.json();if(!r.ok)throw new Error(j.detail||'Cycle impossible');setState(j.state);setLast(j.result)}catch(e){setError(e.message)}finally{setBusy(false)}}
 useEffect(()=>{load();const t=setInterval(load,30000);return()=>clearInterval(t)},[]);
 const p=state?.portfolio, market=state?.market||{}, trades=state?.trades||[], decisions=state?.decisions||[];
 const chart=trades.slice().reverse().reduce((a,t)=>{a.push({name:t.timestamp.slice(11,16),value:100+(t.pnl||0)});return a},[{name:'Départ',value:100}]);
 const agents=['SCANNER','ANALYST','SAFETY','RISK','EXECUTOR','PORTFOLIO'];
 return <div className="shell">
  <aside className="sidebar"><div className="brand"><div className="brandmark">◈</div><div><b>AI TRADING</b><small>CORE / TERMINAL</small></div></div><div className="nav active"><Activity size={17}/> Overview</div><div className="nav"><Wallet size={17}/> Portfolio</div><div className="nav"><Bot size={17}/> AI Agents</div><div className="nav"><Clock3 size={17}/> Trade history</div><div className="sidebottom"><ShieldCheck size={17}/><span>Paper environment<br/><small>Real orders disabled</small></span></div></aside>
  <main className="main">
   <header><div><div className="eyebrow">AUTONOMOUS MULTI-AGENT SYSTEM</div><h1>Trading overview</h1><p>Market intelligence · BTC / ETH · Spot simulation</p></div><div className="header-right"><span className="live"><i/> PAPER MODE</span><button onClick={cycle} disabled={busy}>{busy?<RefreshCw className="spin" size={16}/>:<Zap size={16}/>} Run analysis cycle</button></div></header>
   {error&&<div className="error">Market/API error: {error}. Vérifie que le backend tourne et que les données publiques sont accessibles.</div>}
   <section className="metrics">
    <Metric label="Portfolio equity" value={p?money(p.equity):'—'} sub="Capital fictif total" icon={<Wallet/>}/>
    <Metric label="Total P&L" value={p?money(p.pnl):'—'} sub={p?`${p.pnl_pct}% depuis le départ`:'En attente'} positive={p?.pnl>=0} icon={<Activity/>}/>
    <Metric label="Available cash" value={p?money(p.cash):'—'} sub="Réserve disponible" icon={<CircleDot/>}/>
    <Metric label="Max drawdown" value={p?`${p.drawdown_pct}%`:'—'} sub={p?.halted?'Circuit breaker actif':'Limites surveillées'} icon={<ShieldCheck/>}/>
   </section>
   <section className="gridmain">
    <div className="panel chartpanel"><div className="panelhead"><div><span className="eyebrow">PERFORMANCE</span><h2>Portfolio evolution</h2></div><span className="muted pill">INITIAL €100</span></div><div className="chart"><ResponsiveContainer width="100%" height="100%"><AreaChart data={chart}><defs><linearGradient id="fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#8b7cff" stopOpacity={.3}/><stop offset="100%" stopColor="#8b7cff" stopOpacity={0}/></linearGradient></defs><Area type="monotone" dataKey="value" stroke="#9b8cff" strokeWidth={2} fill="url(#fill)"/><Tooltip contentStyle={{background:'#111827',border:'1px solid #273247',borderRadius:10}} formatter={v=>money(v)}/></AreaChart></ResponsiveContainer></div><div className="chartfoot"><span>Paper portfolio · simulated fills include estimated costs</span><span>{last?'Last cycle: '+new Date(last.timestamp).toLocaleTimeString():'No cycle yet'}</span></div></div>
    <div className="panel"><div className="panelhead"><div><span className="eyebrow">MARKET WATCH</span><h2>Live assets</h2></div><span className="live"><i/> PUBLIC DATA</span></div>{Object.values(market).map(m=><div className="asset" key={m.symbol}><div className="coin">{m.symbol.startsWith('BTC')?'₿':'◆'}</div><div className="assetname"><b>{m.symbol}</b><small>15m · EMA / RSI</small></div><div className="assetprice"><b>{money(m.price)}</b><small>RSI {Number(m.rsi).toFixed(1)}</small></div></div>)}{!Object.keys(market).length&&<div className="empty">Waiting for market data…</div>}</div>
   </section>
   <section className="gridmain lower">
    <div className="panel"><div className="panelhead"><div><span className="eyebrow">MULTI-AGENT SYSTEM</span><h2>Agent status</h2></div><span className="muted pill">6 MODULES</span></div><div className="agents">{agents.map((a,i)=><div className="agent" key={a}><div className={'agenticon c'+i}><Bot size={16}/></div><div><b>{a}</b><small>{['Market data scanner','EMA / RSI analyst','Data & market safety','Position sizing & limits','Paper order execution','Equity & exposure monitor'][i]}</small></div><span className="status">READY</span></div>)}</div></div>
    <div className="panel"><div className="panelhead"><div><span className="eyebrow">DECISION LOG</span><h2>Latest decisions</h2></div></div>{decisions.slice(0,6).map(d=><div className="decision" key={d.id}><div><b>{d.symbol}</b><small>{d.reason}</small></div><span className={'signal '+d.signal.toLowerCase()}>{d.signal}</span></div>)}{!decisions.length&&<div className="empty">Run an analysis cycle to create the first decisions.</div>}</div>
   </section>
   <section className="panel trades"><div className="panelhead"><div><span className="eyebrow">EXECUTION HISTORY</span><h2>Paper trades</h2></div><span className="muted pill">{trades.length} RECORDS</span></div><div className="tablewrap"><table><thead><tr><th>Asset</th><th>Side</th><th>Quantity</th><th>Fill price</th><th>Fee</th><th>Realized P&L</th><th>Time</th></tr></thead><tbody>{trades.map(t=><tr key={t.id}><td>{t.symbol}</td><td><span className={'signal '+t.side.toLowerCase()}>{t.side}</span></td><td>{Number(t.quantity).toFixed(6)}</td><td>{money(t.price)}</td><td>{money(t.fee)}</td><td className={t.pnl>=0?'green':'red'}>{money(t.pnl)}</td><td>{new Date(t.timestamp).toLocaleString()}</td></tr>)}</tbody></table>{!trades.length&&<div className="empty">No simulated trades yet. This is normal: the strategy may decide to wait.</div>}</div></section>
   <footer><span>AI Trading Core v1.0 · Local prototype</span><span>Not financial advice · No real orders · No API keys</span></footer>
  </main>
 </div>
}
function Metric({label,value,sub,icon,positive}){return <div className="metric"><div className="metrichead"><span>{label}</span><div>{icon}</div></div><strong className={positive===false?'red':''}>{value}</strong><small>{sub}</small></div>}
export default App;

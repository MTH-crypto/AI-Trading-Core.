import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .config import settings
from .db import init_db
from .engine import snapshot, run_cycle
from .market import MarketDataError

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    task = None
    if settings.auto_tick:
        async def loop():
            while True:
                try:
                    await asyncio.to_thread(run_cycle)
                except Exception:
                    pass
                await asyncio.sleep(max(30, settings.poll_seconds))
        task = asyncio.create_task(loop())
    yield
    if task:
        task.cancel()

app = FastAPI(title=settings.app_name, version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:5173"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.get("/api/health")
def health():
    return {"status":"ok","mode":"paper","real_orders_enabled":False}

@app.get("/api/state")
def state():
    try:
        return snapshot()
    except MarketDataError as e:
        raise HTTPException(status_code=503, detail=str(e))

@app.post("/api/cycle")
def cycle():
    try:
        result = run_cycle()
        return {"result": result, "state": snapshot()}
    except MarketDataError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/config")
def config():
    return {
        "symbols": settings.symbol_list, "timeframe": settings.timeframe,
        "initial_cash": settings.initial_cash_eur, "mode":"paper",
        "fee_rate": settings.fee_rate, "slippage_rate": settings.slippage_rate
    }

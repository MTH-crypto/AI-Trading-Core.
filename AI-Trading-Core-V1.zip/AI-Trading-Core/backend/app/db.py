import sqlite3
from pathlib import Path
from .config import settings

def connect():
    path = Path(settings.database_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with connect() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS portfolio (
            id INTEGER PRIMARY KEY CHECK (id=1),
            cash REAL NOT NULL,
            initial_cash REAL NOT NULL,
            peak_equity REAL NOT NULL,
            day_start_equity REAL NOT NULL,
            day_key TEXT NOT NULL,
            halted INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS positions (
            symbol TEXT PRIMARY KEY,
            quantity REAL NOT NULL,
            avg_entry REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS trades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            symbol TEXT NOT NULL,
            side TEXT NOT NULL,
            quantity REAL NOT NULL,
            price REAL NOT NULL,
            fee REAL NOT NULL,
            pnl REAL NOT NULL,
            reason TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS decisions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            symbol TEXT NOT NULL,
            signal TEXT NOT NULL,
            reason TEXT NOT NULL,
            agents TEXT NOT NULL
        );
        ''')
        row = c.execute("SELECT id FROM portfolio WHERE id=1").fetchone()
        if not row:
            cash = settings.initial_cash_eur
            from datetime import datetime, timezone
            day = datetime.now(timezone.utc).date().isoformat()
            c.execute("INSERT INTO portfolio(id,cash,initial_cash,peak_equity,day_start_equity,day_key,halted) VALUES(1,?,?,?,?,?,0)",
                      (cash, cash, cash, cash, day))
